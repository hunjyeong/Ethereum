#include <iostream>
#include <openssl/sha.h>
#include <random>
#include <boost/multiprecision/cpp_int.hpp>
#include <fstream>
#include <algorithm>
#include <vector>
#include <string>
#include <numeric>
#include <math.h>
#include <iomanip>
#include <sstream>
#include <openssl/sha.h>

using namespace::std;
using namespace boost::multiprecision;
typedef unsigned char BYTE;

string SHA256(const string strIn)
    {

        BYTE hash[SHA256_DIGEST_LENGTH];
        SHA256_CTX sha256;
        SHA256_Init(&sha256);
        SHA256_Update(&sha256, strIn.c_str(), strIn.size());
        SHA256_Final(hash, &sha256);
        stringstream ss;
        for(int i = 0; i < SHA256_DIGEST_LENGTH; i++)
        ss << hex << setw(2) << setfill('0') << (int)hash[i];
        return ss.str();

    }



uint128_t CSPRNG(){

    random_device rnd;
    uint64_t t1 = rnd();
    uint64_t t2 = rnd();
    uint64_t t3 = rnd();
    uint64_t t4 = rnd();

    string buf = to_string(t1)+to_string(t2)+to_string(t3)+to_string(t4);;

    return uint128_t(buf);

}






int main() {

    string list[2048];
    ifstream ls;
    ls.open("chinese_traditional.txt");

    for(uint32_t i=0;i<2048;i++){
        ls >> list[i];
    }
    ls.close();


    cout<<(CSPRNG()>>124)<<endl;
    cout<<sizeof(CSPRNG())<<endl;

}